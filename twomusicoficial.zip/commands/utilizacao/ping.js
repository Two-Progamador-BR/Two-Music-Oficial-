module.exports = ({
name: "ping",
aliases: ['status'],
code: `$deletecommand $color[35FF00] $thumbnail[$authorAvatar] $footer[Comando requisitado por $username]
$addTimestamp $description[ 
  <@$authorID> ** <:ping:806959853260111874> Meu ping é $ping**]`
})