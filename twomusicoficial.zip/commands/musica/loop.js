module.exports = ({
  name: "loop",
  code: `$deletecommand $deleteIn[1m] $color[RED] $thumbnail`
})
