module.exports = ({
  name: "help",
  aliases: ['ajuda','h'],
  code: `$deletecommand $deleteIn[1m] $thumbnail[$serverIcon] $color[BLUE] $description[
  Ola <@$authorID> **Eu sou Two⁹⁹ Music um bot de musica com qualidade perfeita <a:planeta:806903391598673920> caso queria saber meus comandos É 
  
  <a:x_Seta:806276443151269899> t!play
  <a:x_Seta:806276443151269899> t!stop
  <a:x_Seta:806276443151269899> t!playlist
  <a:x_Seta:806276443151269899> t!skip
  <a:x_Seta:806276443151269899> t!loop]
  `})