module.exports = ({
  name: "queue",
  aliases: ['playlist','q'],
  code: `$title[:signal_strength: Queue]
$description[$queue[1;10]]

$color[BLUE]`
})
